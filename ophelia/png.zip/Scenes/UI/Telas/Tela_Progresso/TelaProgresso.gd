extends Control
## Tela de progresso: navegação funcional; conteúdo poderá ser implementado depois.
signal inventario_solicitado()
signal catalogo_solicitado()

@export_range(0.1, 1.0, 0.05) var duracao_entrada: float = 0.45
@export_range(0.1, 1.0, 0.05) var duracao_saida: float = 0.25
var _transicao: Tween

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    hide()
    var botao_inventario: BaseButton = get_node_or_null("Navegacao/Inventario") as BaseButton
    var botao_catalogo: BaseButton = get_node_or_null("Navegacao/Catalago") as BaseButton
    if botao_inventario != null:
        botao_inventario.pressed.connect(func(): inventario_solicitado.emit())
    if botao_catalogo != null:
        botao_catalogo.pressed.connect(func(): catalogo_solicitado.emit())

func abrir() -> void:
    if _transicao != null and _transicao.is_valid():
        _transicao.kill()
    show()
    pivot_offset = size * 0.5
    modulate.a = 0.0
    scale = Vector2(0.94, 0.94)
    _transicao = create_tween().set_parallel(true)
    _transicao.tween_property(self, "modulate:a", 1.0, duracao_entrada).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    _transicao.tween_property(self, "scale", Vector2.ONE, duracao_entrada).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

func fechar(_notificar: bool = false) -> void:
    if not visible:
        return
    if _transicao != null and _transicao.is_valid():
        _transicao.kill()
    _transicao = create_tween()
    _transicao.tween_property(self, "modulate:a", 0.0, duracao_saida).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
    _transicao.finished.connect(hide)
