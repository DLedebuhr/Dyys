extends Control

@onready var enfeite_revelar: TextureButton = $EnfeiteEsquerda

# Preparar o nó
# ---------------------
# Configura referências, sinais e estado inicial.
func _ready() -> void:

	# Cada slot lê apenas seu próprio arquivo salvo.
	for i in range(mini(slots.size(), 4)):
		var slot := slots[i]
		if slot == null:
			continue
		slot.slot_index = i
		slot.atualizar_exibicao(EstadoPartida.ler_slot(i))
		if not slot.slot_selecionado.is_connected(_ao_selecionar_slot):
			slot.slot_selecionado.connect(_ao_selecionar_slot)

	# Configura o Enfeite da Esquerda (Preview da Animação)

	if enfeite_revelar:

		enfeite_revelar.mouse_entered.connect(_on_enfeite_revelar_mouse_entered)
		enfeite_revelar.mouse_exited.connect(_on_enfeite_revelar_mouse_exited)
	# Configura o Enfeite da Direita (Gatilho do Cheat "ophelia")


# Atualizar a cada quadro
# ---------------------
# Atualiza os temporizadores, a interface ou os efeitos deste nó.
func _process(delta: float) -> void:

	if aguardando_cheat:

		tempo_restante -= delta

		if tempo_restante <= 0.0:

			_cancelar_espera_cheat()
# --- REVELAÇÃO DA ARTE (ENFEITE ESQUERDO) ---

# On enfeite revelar mouse entered
# ---------------------
# Trata o evento de enfeite revelar mouse entered.
func _on_enfeite_revelar_mouse_entered() -> void:

	# Ao passar o mouse no enfeite, todos os vasos animam do 0 ao 6

	for slot in slots:

		if slot:

			slot.animar_preview_progressivo()

# On enfeite revelar mouse exited
# ---------------------
# Trata o evento de enfeite revelar mouse exited.
func _on_enfeite_revelar_mouse_exited() -> void:

	# Ao tirar o mouse, restaura a arte real guardada no save

	for slot in slots:

		if slot:

			slot.restaurar_exibicao_real()

func _ao_selecionar_slot(indice: int, _dados: SaveData) -> void:
	var dados: SaveData = EstadoPartida.selecionar_slot(indice)
	if dados == null:
		return
	var destino: String = dados.cena_atual
	if destino.is_empty() or not ResourceLoader.exists(destino):
		push_warning("Fase do slot indisponível. Abrindo o tutorial; progresso foi preservado.")
		destino = EstadoPartida.TUTORIAL
		dados.cena_atual = destino
		EstadoPartida.gravar()
	# Remove o fundo do menu ao entrar no jogo, se o Autoload estiver instalado.
	var fundo := get_node_or_null("/root/FundoParticulas")
	if fundo != nullnd fundo.has_method("desativar"):
		fundo.call("desativar")
	get_tree().change_scene_to_file(destino)
