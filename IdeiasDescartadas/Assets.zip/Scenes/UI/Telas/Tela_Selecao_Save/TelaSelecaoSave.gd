extends Control

# A seleção de saves pertence às cenas individuais dos vasos.
# Esta tela apenas apresenta o fundo, os espaços e o botão Voltar.

const CENA_PRINCIPAL: String = "res://Scenes/UI/Telas/Tela_Principal/TelaPrincipal.tscn"

@onready var botao_voltar: BaseButton = $Voltar


func _ready() -> void:
	botao_voltar.pressed.connect(_voltar_para_inicio)


func _voltar_para_inicio() -> void:
	get_tree().change_scene_to_file(CENA_PRINCIPAL)
