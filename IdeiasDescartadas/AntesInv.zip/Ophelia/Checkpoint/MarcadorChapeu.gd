extends Node2D
## Chapéu deixado no mundo. Não tem colisão, interação ou coleta.
## Primeiro se fragmenta e converge, depois desce e permanece flutuando.

const TEXTURA_CHAPEU = preload("res://Ophelia/Checkpoint/ChapeuIcone.png")

@export_range(0.1, 2.0, 0.05) var tempo_reunir: float = 0.48
@export_range(0.1, 2.0, 0.05) var tempo_descer: float = 0.56
@export_range(10, 140, 1) var quantidade_particulas: int = 84
@export_range(0.01, 0.5, 0.01) var escala_icone: float = 0.105
@export var amplitude_flutuar: float = 4.0
@export var velocidade_flutuar: float = 2.2

var _tempo: float = 0.0
var _particulas: Array[Dictionary] = []
var _inicio: Vector2 = Vector2(0, -110)
var _reuniao: Vector2 = Vector2(0, -105)
var _imagem: Image

func configurar(inicio_global: Vector2) -> void:
    _inicio = to_local(inicio_global)
    _reuniao = _inicio + Vector2(0, -7)
    _imagem = TEXTURA_CHAPEU.get_image()
    _particulas.clear()
    var gerador := RandomNumberGenerator.new()
    gerador.randomize()
    for i in range(quantidade_particulas):
        var amostra := Vector2.ZERO
        if _imagem != null and not _imagem.is_empty():
            for tentativas in range(80):
                var x: int = gerador.randi_range(0, _imagem.get_width() - 1)
                var y: int = gerador.randi_range(0, _imagem.get_height() - 1)
                if _imagem.get_pixel(x, y).a > 0.5:
                    amostra = Vector2(float(x) - _imagem.get_width() * 0.5, float(y) - _imagem.get_height() * 0.5) * 0.32
                    break
        else:
            amostra = Vector2(gerador.randf_range(-55, 55), gerador.randf_range(-35, 35))
        _particulas.append({"pos": _inicio + amostra, "fase": gerador.randf() * TAU, "tam": gerador.randf_range(1.1, 2.9)})
    queue_redraw()

func _process(delta: float) -> void:
    _tempo += delta
    queue_redraw()

func _draw() -> void:
    var fim: float = tempo_reunir + tempo_descer
    if _tempo < fim:
        var reunindo: bool = _tempo < tempo_reunir
        var progresso: float = clampf(_tempo / tempo_reunir, 0.0, 1.0) if reunindo else clampf((_tempo - tempo_reunir) / tempo_descer, 0.0, 1.0)
        var suave: float = progresso * progresso * (3.0 - 2.0 * progresso)
        var ponto: Vector2 = _reuniao.lerp(Vector2(0, -28), suave)
        for p in _particulas:
            var posicao: Vector2 = Vector2(p["pos"]).lerp(_reuniao, suave) if reunindo else ponto
            var fase: float = float(p["fase"])
            posicao += Vector2(cos(_tempo * 15.0 + fase), sin(_tempo * 18.0 + fase)) * (1.4 if reunindo else 2.4 * (1.0 - suave))
            draw_circle(posicao, float(p["tam"]) * (1.0 - 0.45 * suave), Color(0.67, 0.98, 0.89, 0.85))
        if not reunindo:
            draw_circle(ponto, 4.0 + (1.0 - suave) * 2.0, Color(0.89, 1.0, 0.96, 0.45))
        return

    var entrada: float = clampf((_tempo - fim) / 0.38, 0.0, 1.0)
    var flutuar: float = sin((_tempo - fim) * velocidade_flutuar) * amplitude_flutuar
    var centro := Vector2(0, -29 + flutuar)
    var tamanho: Vector2 = TEXTURA_CHAPEU.get_size() * escala_icone
    draw_circle(centro, 22.0, Color(0.39, 0.80, 0.72, 0.035 + 0.045 * entrada))
    draw_texture_rect(TEXTURA_CHAPEU, Rect2(centro - tamanho * 0.5, tamanho), false, Color(1, 1, 1, entrada))
    var brilhos: float = sin(_tempo * 2.5) * 0.5 + 0.5
    draw_circle(centro + Vector2(0, -tamanho.y * 0.6 - 3.0), 1.8 + brilhos, Color(0.9, 1.0, 1.0, entrada * (0.45 + 0.45 * brilhos)))
