extends Node2D
## Marcador sem colisão: forma-se a partir de pontos na forma do chapéu, flutua,
## e, ao ser chamado, desliza até a personagem deixando um rastro de cintilos.
signal recolhido()
const TEXTURA_CHAPEU = preload("res://Ophelia/Checkpoint/ChapeuIcone.svg")
const ESTILO = preload("res://Ophelia/Efeitos/EstiloParticulas.tres")
@export_range(0.1, 2.0, 0.05) var tempo_reunir: float = 0.48
@export_range(0.1, 2.0, 0.05) var tempo_descer: float = 0.56
@export_range(20, 200, 1) var quantidade_particulas: int = 90
@export_range(0.01, 0.5, 0.01) var escala_icone: float = 0.105
@export var amplitude_flutuar: float = 4.0
@export var velocidade_flutuar: float = 2.2
@export_range(80, 850, 10) var velocidade_retorno: float = 330.0
@export_range(0.5, 5.0, 0.1) var fator_aceleracao: float = 1.45
const MONTANDO := 0
const FLUTUANDO := 1
const RETORNANDO := 2
var _estado: int = MONTANDO
var _tempo: float = 0.0
var _inicio: Vector2 = Vector2.ZERO
var _reuniao: Vector2 = Vector2.ZERO
var _particulas: Array[Dictionary] = []
var _alvo: Node2D
var _particulas_rastro: Array[Dictionary] = []
var _velocidade_atual: float = 0.0
var _tempo_emissao: float = 0.0

func configurar(inicio_global: Vector2) -> void:
	_estado = MONTANDO
	_tempo = 0.0
	_inicio = to_local(inicio_global)
	_reuniao = _inicio + Vector2(0, -8)
	_particulas.clear()
	var img: Image = TEXTURA_CHAPEU.get_image()
	if img != null and img.is_compressed():
		if img.decompress() != OK:
			img = null
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(quantidade_particulas):
		var pos := Vector2(rng.randf_range(-30, 30), rng.randf_range(-16, 16))
		if img != null and not img.is_empty():
			for tentativa in range(80):
				var x := rng.randi_range(0, img.get_width() - 1)
				var y := rng.randi_range(0, img.get_height() - 1)
				if img.get_pixel(x, y).a > 0.3:
					pos = (Vector2(x, y) - Vector2(img.get_size()) * 0.5) * 0.32
					break
		_particulas.append({"pos": _inicio + pos, "fase": rng.randf() * TAU,
							"tam": rng.randf_range(1.0, 2.8)})
	queue_redraw()

func ativar_instantaneo() -> void:
	_estado = FLUTUANDO
	_tempo = tempo_reunir + tempo_descer + 1.0
	queue_redraw()

func iniciar_retorno(alvo: Node2D) -> void:
	if _estado == RETORNANDO or not is_instance_valid(alvo):
		return
	_alvo = alvo
	_estado = RETORNANDO
	_velocidade_atual = velocidade_retorno * 0.35
	_particulas_rastro.clear()

func esta_retornando() -> bool:
	return _estado == RETORNANDO

func _process(delta: float) -> void:
	_tempo += delta
	if _estado == MONTANDO and _tempo >= tempo_reunir + tempo_descer + 0.35:
		_estado = FLUTUANDO
	if _estado == RETORNANDO:
		_atualizar_retorno(delta)
	for i in range(_particulas_rastro.size() - 1, -1, -1):
		_particulas_rastro[i]["vida"] -= delta
		if float(_particulas_rastro[i]["vida"]) <= 0.0:
			_particulas_rastro.remove_at(i)
	queue_redraw()

func _atualizar_retorno(delta: float) -> void:
	if not is_instance_valid(_alvo):
		_estado = FLUTUANDO
		return
	var destino := _alvo.global_position + Vector2(0, -40)
	_velocidade_atual = minf(velocidade_retorno * 2.0, _velocidade_atual + velocidade_retorno * fator_aceleracao * delta)
	global_position = global_position.move_toward(destino, _velocidade_atual * delta)
	_tempo_emissao += delta
	while _tempo_emissao >= 0.018:
		_tempo_emissao -= 0.018
		for i in range(2):
			_particulas_rastro.append({"pos": global_position + Vector2(randf_range(-9, 9), randf_range(-18, -2)),
				"vida": randf_range(0.3, 0.58), "total": 0.58, "tam": randf_range(1.0, 2.6)})
	if global_position.distance_to(destino) < 10.0:
		recolhido.emit()

func _draw() -> void:
	var cor: Color = ESTILO.get("cor")
	if _estado == MONTANDO:
		var reunindo: bool = _tempo < tempo_reunir
		var t: float = clampf(_tempo / tempo_reunir, 0.0, 1.0) if reunindo else clampf((_tempo - tempo_reunir) / tempo_descer, 0.0, 1.0)
		var suave: float = t * t * (3.0 - 2.0 * t)
		var centro: Vector2 = _reuniao.lerp(Vector2(0, -29), suave)
		for p in _particulas:
			var amostra: Vector2 = p["pos"]
			var onde: Vector2 = amostra.lerp(_reuniao, suave) if reunindo else centro
			var f: float = float(p["fase"])
			onde += Vector2(cos(_tempo * 14.0 + f), sin(_tempo * 17.0 + f)) * (1.7 if reunindo else 2.0 * (1.0 - suave))
			OpheliaEfeitosComuns.desenhar_cintilo(self, onde, float(p["tam"]) * 4.0 * (1.0 - 0.3 * suave), cor)
		return
	var flutuar: float = sin(_tempo * velocidade_flutuar) * amplitude_flutuar
	var centro := Vector2(0, -29 + flutuar) if _estado == FLUTUANDO else Vector2.ZERO
	var tamanho: Vector2 = TEXTURA_CHAPEU.get_size() * escala_icone
	var brilho: float = 0.7 + 0.3 * sin(_tempo * 3.0)
	draw_circle(centro, 22.0, Color(cor.r, cor.g, cor.b, 0.09 * brilho))
	draw_texture_rect(TEXTURA_CHAPEU, Rect2(centro - tamanho * 0.5, tamanho), false)
	draw_arc(centro, 21.0, 0.0, TAU, 36, Color(cor.r, cor.g, cor.b, 0.27 * brilho), 1.3)
	for p in _particulas_rastro:
		var alfa: float = clampf(float(p["vida"]) / float(p["total"]), 0.0, 1.0)
		OpheliaEfeitosComuns.desenhar_cintilo(self, to_local(p["pos"]), float(p["tam"]) * 4.2 * alfa,
											  Color(cor.r, cor.g, cor.b, alfa))
