extends Node2D
## R coloca o chapéu no chão; R novamente chama o ícone até a Ophelia.
## Sem chapéu na cabeça, morrer usa o marcador; com chapéu, usa início da fase.
const CENA_MARCADOR = preload("res://Ophelia/Checkpoint/MarcadorChapeu.tscn")
const ESTILO = preload("res://Ophelia/Efeitos/EstiloParticulas.tres")
@export_group("Chapéu / Checkpoint")
@export var tecla_checkpoint: Key = KEY_R
@export_flags_2d_physics var mascara_chao: int = 1
@export_range(20.0, 200.0, 1.0) var alcance_achar_chao: float = 135.0
@export_range(0.1, 2.0, 0.05) var tempo_materializacao: float = 0.60
var _corpo: CharacterBody2D
var _marcador: Node2D
var _posicao_checkpoint: Vector2
var _usou_checkpoint: bool = false
var _reconstruindo: float = -1.0
var _colocar_pendente: bool = false

func _ready() -> void:
	_corpo = get_parent() as CharacterBody2D
	call_deferred("_iniciar_com_chapeu")

func _iniciar_com_chapeu() -> void:
	if is_instance_valid(_corpo) and _corpo.has_method("definir_chapeu"):
		_corpo.call("definir_chapeu", true)

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return
	var tecla := event as InputEventKey
	if not tecla.pressed or tecla.echo or (tecla.keycode != tecla_checkpoint and tecla.physical_keycode != tecla_checkpoint):
		return
	if not is_instance_valid(_corpo) or _corpo.process_mode == Node.PROCESS_MODE_DISABLED:
		return
	var vida := _corpo.get_node_or_null("Vitalidade")
	if vida != null and vida.has_method("esta_viva") and not vida.call("esta_viva"):
		return
	if is_instance_valid(_marcador):
		if not _marcador.call("esta_retornando"):
			chamar_chapeu()
			get_viewport().set_input_as_handled()
	elif _corpo.is_on_floor() and bool(_corpo.get("usando_chapeu")):
		_colocar_pendente = true
		get_viewport().set_input_as_handled()

func _physics_process(_delta: float) -> void:
	# A consulta física do chão deve acontecer dentro do passo de física.
	if _colocar_pendente:
		_colocar_pendente = false
		colocar_checkpoint()

func _achar_chao() -> Dictionary:
	var origem := _corpo.global_position - Vector2(0, 8)
	var destino := origem + Vector2(0, alcance_achar_chao)
	var consulta := PhysicsRayQueryParameters2D.create(origem, destino, mascara_chao, [_corpo.get_rid()])
	return _corpo.get_world_2d().direct_space_state.intersect_ray(consulta)

func colocar_checkpoint() -> bool:
	if not is_instance_valid(_corpo) or not _corpo.is_on_floor() or is_instance_valid(_marcador):
		return false
	var chao := _achar_chao()
	if chao.is_empty():
		return false
	var normal: Vector2 = chao["normal"]
	if normal.y > -0.55:
		return false
	var mundo := get_tree().current_scene
	if mundo == null:
		return false
	_posicao_checkpoint = _corpo.global_position
	_marcador = CENA_MARCADOR.instantiate()
	mundo.add_child(_marcador)
	_marcador.global_position = chao["position"]
	_marcador.z_index = _corpo.z_index
	_marcador.call("configurar", _corpo.global_position + Vector2(0, -40))
	_marcador.connect("recolhido", _ao_recolher)
	_corpo.call("definir_chapeu", false)
	_avisar_save()
	return true

func chamar_chapeu() -> void:
	if is_instance_valid(_marcador):
		_marcador.call("iniciar_retorno", _corpo)

func _ao_recolher() -> void:
	if is_instance_valid(_marcador):
		_marcador.queue_free()
		_marcador = null
	_reconstruindo = 0.0
	_avisar_save()

func consumir_checkpoint(posicao_padrao: Vector2) -> Vector2:
	_usou_checkpoint = false
	if not is_instance_valid(_marcador):
		return posicao_padrao
	_usou_checkpoint = true
	var destino := _posicao_checkpoint
	_marcador.queue_free()
	_marcador = null
	return destino

func restaurar_chapeu() -> void:
	if not is_instance_valid(_corpo):
		return
	if _usou_checkpoint:
		_corpo.call("definir_chapeu", false)
		_reconstruindo = 0.0
		_usou_checkpoint = false
	else:
		_corpo.call("definir_chapeu", true)
	_avisar_save()

func exportar_estado_save() -> Dictionary:
	var estado := {"posto": bool(_corpo.get("usando_chapeu")) if is_instance_valid(_corpo) else true,
					"ativo": is_instance_valid(_marcador)}
	if is_instance_valid(_marcador):
		estado["checkpoint"] = [_posicao_checkpoint.x, _posicao_checkpoint.y]
		estado["marcador"] = [_marcador.global_position.x, _marcador.global_position.y]
	return estado

func importar_estado_save(dados: Dictionary) -> void:
	if is_instance_valid(_marcador):
		_marcador.queue_free()
		_marcador = null
	if not is_instance_valid(_corpo):
		return
	var pos: Array = dados.get("checkpoint", [])
	var marca: Array = dados.get("marcador", [])
	if bool(dados.get("ativo", false)) and pos.size() == 2 and marca.size() == 2:
		_posicao_checkpoint = Vector2(float(pos[0]), float(pos[1]))
		var mundo := get_tree().current_scene
		if mundo != null:
			_marcador = CENA_MARCADOR.instantiate()
			mundo.add_child(_marcador)
			_marcador.global_position = Vector2(float(marca[0]), float(marca[1]))
			_marcador.z_index = _corpo.z_index
			_marcador.call("ativar_instantaneo")
			_marcador.connect("recolhido", _ao_recolher)
			_corpo.call("definir_chapeu", false)
			return
	_corpo.call("definir_chapeu", true)

func _avisar_save() -> void:
	var controle := _corpo.get_node_or_null("PersistenciaOphelia") if is_instance_valid(_corpo) else null
	if controle != null and controle.has_method("_solicitar_salvar"):
		controle.call("_solicitar_salvar")

func _process(delta: float) -> void:
	if _reconstruindo < 0.0 or not is_instance_valid(_corpo):
		return
	_reconstruindo += delta
	if _reconstruindo >= tempo_materializacao * 0.75 and not bool(_corpo.get("usando_chapeu")):
		_corpo.call("definir_chapeu", true)
	queue_redraw()
	if _reconstruindo >= tempo_materializacao:
		_reconstruindo = -1.0
		_avisar_save()

func _draw() -> void:
	if _reconstruindo < 0.0:
		return
	var t := clampf(_reconstruindo / tempo_materializacao, 0.0, 1.0)
	var cor: Color = ESTILO.get("cor")
	var centro := Vector2(0, -40)
	for i in range(75):
		var fase := TAU * float(i) / 75.0
		var raio := lerpf(60.0, 6.0, t * t)
		var ponto := centro + Vector2(cos(fase) * raio, sin(fase * 1.9) * raio * 0.55)
		OpheliaEfeitosComuns.desenhar_cintilo(self, ponto, 6.0, Color(cor.r, cor.g, cor.b, sin(PI * t) * 0.9))
