extends Control
## Mostra somente as espécies catalogadas no slot ativo.
## A arte de fundo e todas as posições dos TextureRect permanecem na cena original.
signal voltar_inventario_solicitado()
signal progresso_solicitado()

@export_group("Imagens opcionais por espécie")
@export var imagens_especies: Dictionary[StringName, Texture2D] = {}
@export_group("Visual das espécies")
@export var mostrar_nome_no_hover: bool = true

const PASTA_ICONES := "res://Assets/Textures/UI/Tela_Inventario/Flores"
const ESPECIES := {
    "Calla": "IconeCalla.png",
    "Lotus": "IconeLótus.png",
    "Lirio": "IconeLírio.png",
    "Cosmos": "IconeCosmos.png",
    "Lavanda": "IconeLavanda.png",
    "Colquico": "IconeCólquico.png",
    "Princesa": "IconePrincesa.png",
    "Viola": "IconeViola.png",
    "Dalia": "IconeDália.png",
    "Azaleia": "IconeAzaleia.png",
    "Heleboro": "IconeHeléboro.png",
    "Primula": "IconePrímula.png",
    "FlocoNeve": "IconeFlocoNeve.png",
    "Ciclame": "IconeCiclame.png",
    "Camelia": "IconeCamélia.png",
    "Muguet": "IconeMuguet.png",
    "Sakura": "IconeSakura.png",
    "Narciso": "IconeNarciso.png",
    "Iris": "IconenÍris.png",
    "Tulipa": "IconeTulipa.png"
}

const EFEITO_REGISTRO = preload("res://Scenes/UI/Telas/Tela_Catalago/EfeitoRegistroCatalogo.gd")
@export_group("Efeito de nova espécie")
@export_range(0.6, 3.0, 0.05) var duracao_novo_registro: float = 1.45
@export_range(0.0, 1.0, 0.05) var pausa_entre_registros: float = 0.22
var _aberto: bool = false
var _efeito_atual: Control
var _tempo_pausa: float = -1.0
var _fila_bloqueada: bool = false


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    # A cena é aberta pelo inventário sobre a partida pausada.
    hide()
    var voltar := get_node_or_null("Navegacao/Inventario") as BaseButton
    if voltar != null:
        voltar.pressed.connect(_voltar_ao_inventario)
    var progresso := get_node_or_null("Navegacao/Progresso") as BaseButton
    if progresso != null:
        progresso.pressed.connect(_ao_pedir_progresso)
    var fundo := get_node_or_null("Fundo") as Control
    if fundo != null:
        fundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _atualizar_especies()

func abrir() -> void:
    _atualizar_especies()
    _aberto = true
    _fila_bloqueada = false
    _tempo_pausa = -1.0
    show()
    _mostrar_proxima_animacao()

func fechar() -> void:
    if not _aberto:
        return
    _aberto = false
    _tempo_pausa = -1.0
    if is_instance_valid(_efeito_atual):
        _efeito_atual.queue_free()
    _efeito_atual = null
    hide()
    voltar_inventario_solicitado.emit()

func _voltar_ao_inventario() -> void:
    fechar()

func _ao_pedir_progresso() -> void:
    progresso_solicitado.emit()

func _unhandled_input(event: InputEvent) -> void:
    if not _aberto:
        return
    if event is InputEventKey and event.echo:
        return
    if event.is_action_pressed(&"ui_cancel") or (InputMap.has_action(&"ControleInventario") and event.is_action_pressed(&"ControleInventario")):
        get_viewport().set_input_as_handled()
        fechar()

func _atualizar_especies() -> void:
    for estacao in ["Verao", "Outono", "Inverno", "Primavera"]:
        var grupo := get_node_or_null(estacao)
        if grupo == null:
            continue
        for filho in grupo.get_children():
            if not (filho is TextureRect):
                continue
            var retrato := filho as TextureRect
            var especie := StringName(retrato.name)
            if not ESPECIES.has(String(especie)):
                continue
            # O campo mantém exatamente a posição e o tamanho escolhidos no editor.
            retrato.mouse_filter = Control.MOUSE_FILTER_PASS
            retrato.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
            retrato.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
            var registrada := EstadoPartida.especie_registrada(especie)
            retrato.texture = _icone(especie) if registrada else null
            if mostrar_nome_no_hover:
                retrato.tooltip_text = String(especie) if registrada else "Espécie não registrada"
            else:
                retrato.tooltip_text = ""

func _icone(especie: StringName) -> Texture2D:
    var personalizada := imagens_especies.get(especie) as Texture2D
    if personalizada != null:
        return personalizada
    var nome_arquivo: String = ESPECIES.get(String(especie), "")
    if nome_arquivo.is_empty():
        return null
    var caminho := PASTA_ICONES.path_join(nome_arquivo)
    if not ResourceLoader.exists(caminho):
        push_warning("Catálogo: ícone não encontrado: " + caminho)
        return null
    return load(caminho) as Texture2D

# Apenas um registro por vez, obedecendo a ordem salva no slot ativo.
func _mostrar_proxima_animacao() -> void:
    if not _aberto or _fila_bloqueada or is_instance_valid(_efeito_atual):
        return
    var pendentes: Array = EstadoPartida.animacoes_catalogo_pendentes()
    if pendentes.is_empty():
        return
    var especie := StringName(pendentes[0])
    var retrato: TextureRect = _retrato_da_especie(especie)
    if retrato == null:
        # Evita travar toda a fila se uma espécie antiga deixou de existir na interface.
        if EstadoPartida.confirmar_animacao_catalogo(especie):
            call_deferred("_mostrar_proxima_animacao")
        else:
            _fila_bloqueada = true
        return
    var centro: Vector2 = retrato.get_global_rect().get_center() - get_global_rect().position
    var icone: Texture2D = _icone_encapsulada(especie)
    _efeito_atual = EFEITO_REGISTRO.new() as Control
    add_child(_efeito_atual)
    _efeito_atual.connect("terminou", Callable(self, "_ao_terminar_animacao").bind(especie), CONNECT_ONE_SHOT)
    _efeito_atual.call("iniciar", icone, centro, duracao_novo_registro)

func _ao_terminar_animacao(especie: StringName) -> void:
    _efeito_atual = null
    if not _aberto:
        return
    if not EstadoPartida.confirmar_animacao_catalogo(especie):
        push_warning("Catálogo: falha ao marcar a animação de %s como exibida." % String(especie))
        _fila_bloqueada = true
        return
    _tempo_pausa = pausa_entre_registros
    if _tempo_pausa <= 0.0:
        _mostrar_proxima_animacao()

func _process(delta: float) -> void:
    if not _aberto or _tempo_pausa < 0.0:
        return
    _tempo_pausa -= delta
    if _tempo_pausa <= 0.0:
        _tempo_pausa = -1.0
        _mostrar_proxima_animacao()

func _retrato_da_especie(especie: StringName) -> TextureRect:
    for estacao in ["Verao", "Outono", "Inverno", "Primavera"]:
        var retrato := get_node_or_null(NodePath(estacao + "/" + String(especie))) as TextureRect
        if retrato != null:
            return retrato
    return null

func _icone_encapsulada(especie: StringName) -> Texture2D:
    # Usa os ícones reais das cápsulas; não procura o arquivo na pasta Flores.
    var nome: String = ESPECIES.get(String(especie), "")
    if not nome.is_empty():
        var caminho: String = "res://Assets/Textures/UI/Tela_Inventario/Capsulas/" + nome.trim_suffix(".png") + "Encapsulada.png"
        if ResourceLoader.exists(caminho):
            return load(caminho) as Texture2D
    return _icone(especie)
