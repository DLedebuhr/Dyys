extends Node2D
## Sistema de checkpoint descartável vinculado à Ophelia.
## R: deposita o chapéu no chão; na próxima morte, nasce nesse ponto e o recupera.

const CENA_MARCADOR = preload("res://Ophelia/Checkpoint/MarcadorChapeu.gd")

@export_group("Chapéu / Checkpoint")
@export var tecla_checkpoint: Key = KEY_R
@export_range(20.0, 120.0, 1.0) var deslocamento_ate_chao: float = 83.0
@export_range(0.1, 2.0, 0.05) var tempo_materializacao: float = 0.60

var _corpo: CharacterBody2D
var _marcador: Node2D
var _posicao_checkpoint: Vector2
var _usou_checkpoint: bool = false
var _reconstruindo: float = -1.0

func _ready() -> void:
	_corpo = get_parent() as CharacterBody2D
	call_deferred("_iniciar_com_chapeu")

func _iniciar_com_chapeu() -> void:
	if is_instance_valid(_corpo) and _corpo.has_method("definir_chapeu"):
		_corpo.call("definir_chapeu", true)

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return
	var tecla := event as InputEventKey
	if not tecla.pressed or tecla.echo or (tecla.keycode != tecla_checkpoint and tecla.physical_keycode != tecla_checkpoint):
		return
	if not is_instance_valid(_corpo) or _corpo.process_mode == Node.PROCESS_MODE_DISABLED:
		return
	var vida: Node = _corpo.get_node_or_null("Vitalidade")
	if vida != null and vida.has_method("esta_viva") and not bool(vida.call("esta_viva")):
		return
	if not _corpo.is_on_floor() or not bool(_corpo.get("usando_chapeu")) or is_instance_valid(_marcador):
		return
	colocar_checkpoint()
	get_viewport().set_input_as_handled()

func colocar_checkpoint() -> void:
	_posicao_checkpoint = _corpo.global_position
	var mundo: Node = get_tree().current_scene
	if mundo == null:
		mundo = get_tree().root
	_marcador = CENA_MARCADOR.new() as Node2D
	mundo.add_child(_marcador)
	_marcador.global_position = _corpo.global_position + Vector2(0, deslocamento_ate_chao)
	_marcador.z_index = _corpo.z_index
	_marcador.call("configurar", _corpo.global_position + Vector2(0, -39))
	_corpo.call("definir_chapeu", false)

func consumir_checkpoint(posicao_padrao: Vector2) -> Vector2:
	_usou_checkpoint = false
	if not is_instance_valid(_marcador):
		return posicao_padrao
	_usou_checkpoint = true
	var destino := _posicao_checkpoint
	_marcador.queue_free()
	_marcador = null
	return destino

func restaurar_chapeu() -> void:
	if not is_instance_valid(_corpo):
		return
	if _usou_checkpoint:
		_corpo.call("definir_chapeu", false)
		_reconstruindo = 0.0
		_usou_checkpoint = false
	else:
		_corpo.call("definir_chapeu", true)

func _process(delta: float) -> void:
	if _reconstruindo < 0.0:
		return
	_reconstruindo += delta
	if _reconstruindo >= tempo_materializacao * 0.68 and not bool(_corpo.get("usando_chapeu")):
		_corpo.call("definir_chapeu", true)
	queue_redraw()
	if _reconstruindo >= tempo_materializacao:
		_reconstruindo = -1.0
		queue_redraw()

func _draw() -> void:
	if _reconstruindo < 0.0:
		return
	var t: float = clampf(_reconstruindo / tempo_materializacao, 0.0, 1.0)
	var centro := Vector2(0, -39)
	for i in range(52):
		var fase: float = TAU * float(i) / 52.0
		var raio: float = lerpf(72.0, 9.0, t * t)
		var ponto := centro + Vector2(cos(fase) * raio, sin(fase * 1.7) * raio * 0.5 - 9.0 * (1.0 - t))
		var cor := Color(0.65, 0.97, 0.87, sin(PI * t) * 0.85)
		draw_circle(ponto, 1.3 + sin(fase * 3.0 + _reconstruindo * 8.0) * 0.5, cor)
