extends Sprite2D
## Animacao suave de bolhas ja desenhadas nos quatro SVGs da pasta Espuma.
## Nao emite gotas nem particulas e nao interage com fisica.

@export var quadros: Array[Texture2D] = []
@export_range(0.15, 2.0, 0.05) var tempo_por_quadro: float = 0.52
@export_range(0.0, 5.0, 0.1) var movimento_horizontal: float = 2.0
@export_range(0.0, 5.0, 0.1) var movimento_vertical: float = 1.1
@export var fase: float = 0.0

var _base: Vector2
var _alpha_base: float
var _tempo: float = 0.0


func _ready() -> void:
	_base = position
	_alpha_base = modulate.a
	_tempo = fase
	if not quadros.is_empty():
		texture = quadros[0]


func _process(delta: float) -> void:
	_tempo += delta
	if quadros.size() > 1:
		var n: int = quadros.size()
		var periodo: int = (n - 1) * 2
		var passo: int = int(floor(_tempo / maxf(tempo_por_quadro, 0.05))) % periodo
		var indice: int = passo if passo < n else periodo - passo
		texture = quadros[indice]
	position = _base + Vector2(sin(_tempo * 0.67) * movimento_horizontal, cos(_tempo * 0.83) * movimento_vertical)
	var alpha: float = _alpha_base * (0.94 + sin(_tempo * 1.2) * 0.06)
	modulate.a = clampf(alpha, 0.0, 1.0)
