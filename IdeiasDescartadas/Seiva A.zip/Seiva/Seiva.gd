@tool
extends Node2D

signal capsula_preenchida(jogador: CharacterBody2D)

@export_group("Interação")
@export var acao_interagir: StringName = &"ControleInteragir"
@export_range(10.0, 500.0, 1.0) var distancia_coleta: float = 100.0
@export var acompanhar_bacias: bool = true
@export var mensagem_encher: String = "ENCHER CÁPSULA"
@export var mensagem_sem_capsulas: String = "SEM CÁPSULAS DISPONÍVEIS"

@export_group("Som ao encher")
@export var som_encher: AudioStream
@export var barramento_som: StringName = &"Master"
@export var volume_encher_db: float = 0.0

@export_group("Profundidade visual — Seiva")
## A Ophelia é uma única unidade visual: corpo, lenço traseiro, lenço frontal e pontas.
## Ao alcançar uma bacia pelo alto, todo esse conjunto passa atrás da Base e da Sobreposição.
@export var profundidade_automatica: bool = true
@export_range(-100, 100, 1) var z_ophelia_frente: int = 2
@export_range(-100, 100, 1) var z_ophelia_atras: int = -7
@export_range(0.0, 100.0, 1.0) var margem_lateral_bacias: float = 8.0
@export_range(0.0, 100.0, 1.0) var margem_altura_bacias: float = 20.0

var _avisou_integracao: bool = false
var _jogador_visual: CharacterBody2D
var _z_jogador_original: int = 2


# Preparar a fonte
# ---------------------
# Mantém a água independente da interação e prepara os pontos das três bacias.
func _ready() -> void:

	_atualizar_pontos()


# Acompanhar os ajustes da água
# ---------------------
# Faz os pontos de interação seguirem as bacias editadas na cena de água.
func _process(_delta: float) -> void:

	_atualizar_pontos()
	if not Engine.is_editor_hint():

		_atualizar_profundidade()


# Camada de profundidade da Ophelia
# ---------------------
# Só altera o Z do CharacterBody2D inteiro, sem destacar lenço nem pontas.
# Preserva as camadas físicas e não muda a arte ou a animação.
func _atualizar_profundidade() -> void:

	var encontrado: CharacterBody2D = get_tree().get_first_node_in_group("jogador") as CharacterBody2D
	if encontrado != _jogador_visual:

		_restaurar_profundidade()
		_jogador_visual = encontrado
		if is_instance_valid(_jogador_visual):

			_z_jogador_original = _jogador_visual.z_index

	if not is_instance_valid(_jogador_visual):

		return

	if not profundidade_automatica:

		_jogador_visual.z_index = _z_jogador_original
		return

	_jogador_visual.z_index = z_ophelia_atras if _jogador_sobre_bacia() else z_ophelia_frente


# Restaurar o jogador quando a Seiva sair da cena
# ---------------------
func _exit_tree() -> void:

	_restaurar_profundidade()


func _restaurar_profundidade() -> void:

	if is_instance_valid(_jogador_visual):

		_jogador_visual.z_index = _z_jogador_original
	_jogador_visual = null


# Posição real dos pés
# ---------------------
# Usa a mesma cápsula física que o controlador e os efeitos da água já utilizam.
func _pes_jogador() -> Vector2:

	var pes: Vector2 = _jogador_visual.global_position
	var forma: CollisionShape2D = _jogador_visual.get_node_or_null("ColisaoCorpo") as CollisionShape2D
	if forma == null or forma.shape == null:

		return pes

	var limites: Rect2 = forma.shape.get_rect()
	var cantos: Array[Vector2] = [
		limites.position,
		Vector2(limites.end.x, limites.position.y),
		limites.end,
		Vector2(limites.position.x, limites.end.y)
	]
	for canto in cantos:

		pes.y = maxf(pes.y, forma.to_global(canto).y)
	return pes


# Descobrir se a personagem está acima / apoiada em alguma bacia
# ---------------------
# Caminhando no chão à frente, os pés ficam abaixo da borda e tudo aparece na frente.
# Pulando ou pousando sobre o vaso, a personagem inteira fica atrás da Base e da Sobreposição.
func _jogador_sobre_bacia() -> bool:

	if _jogador_visual.is_on_floor():

		for i in range(_jogador_visual.get_slide_collision_count()):

			var contato: KinematicCollision2D = _jogador_visual.get_slide_collision(i)
			if contato.get_normal().y > -0.65:

				continue

			var alvo: Object = contato.get_collider()
			if alvo == $Colisoes/BaciaSuperior or alvo == $Colisoes/BaciaMeio or alvo == $Colisoes/BaciaInferior:

				return true

	var pes: Vector2 = _pes_jogador()
	for i in range(1, 4):

		var bacia: Node2D = get_node_or_null("Agua/Ponto%d/Agua" % i) as Node2D
		if bacia == null:

			continue

		var local: Vector2 = bacia.to_local(pes)
		var dimensoes: Vector2 = bacia.get("tamanho")
		if local.x < -margem_lateral_bacias or local.x > dimensoes.x + margem_lateral_bacias:

			continue

		var x: float = clampf(local.x, 0.0, dimensoes.x)
		var linha_agua: Vector2 = bacia.to_global(Vector2(x, float(bacia.call("altura", x))))
		if pes.y <= linha_agua.y + margem_altura_bacias:

			return true

	return false


# Atualizar os pontos de coleta
# ---------------------
# Usa o centro de cada bacia; desative o acompanhamento para posicionar manualmente.
func _atualizar_pontos() -> void:

	if not is_node_ready():

		return

	for i in range(1, 4):

		var ponto: Marker2D = get_node("PontosColeta/Bacia%d" % i) as Marker2D

		if acompanhar_bacias:

			var agua: Node2D = get_node("Agua/Ponto%d/Agua" % i) as Node2D
			var dimensoes: Vector2 = agua.get("tamanho")
			ponto.global_position = agua.to_global(dimensoes * 0.5)

		if not Engine.is_editor_hint():

			ponto.set("acao_interagir", acao_interagir)
			ponto.set("distancia_coleta", distancia_coleta)


# Consultar o inventário da personagem
# ---------------------
# Usa o mesmo nó Inventario empregado pelos demais coletáveis.
func _obter_inventario(jogador: CharacterBody2D) -> Node:

	if not is_instance_valid(jogador):

		return null

	return jogador.get_node_or_null("Inventario")


# Consultar cápsulas vazias
# ---------------------
# Considera apenas as cápsulas guardadas na bolsa, sem retirar ingredientes da oficina.
func possui_capsula(jogador: CharacterBody2D) -> bool:

	var inventario: Node = _obter_inventario(jogador)

	return inventario != null and inventario.has_method("quantidade") and int(inventario.call("quantidade", &"Capsula")) > 0


# Escolher a mensagem da fonte
# ---------------------
# Mantém a indicação visível mesmo quando não existe cápsula para encher.
func obter_mensagem(jogador: CharacterBody2D) -> String:

	return mensagem_encher if possui_capsula(jogador) else mensagem_sem_capsulas


# Encher uma cápsula
# ---------------------
# Solicita uma troca atômica no mesmo espaço da bolsa, sem remover ou adicionar por etapas.
func encher_capsula(jogador: CharacterBody2D) -> bool:

	if Engine.is_editor_hint() or get_tree().paused or not possui_capsula(jogador):

		return false

	var inventario: Node = _obter_inventario(jogador)

	if not inventario.has_method("encher_capsula_com_seiva"):

		if not _avisou_integracao:

			_avisou_integracao = true
			push_warning("Seiva: adicione encher_capsula_com_seiva() ao script atual do inventário.")

		return false

	if not bool(inventario.call("encher_capsula_com_seiva")):

		return false

	_tocar_som(jogador.global_position)
	capsula_preenchida.emit(jogador)

	return true


# Tocar o preenchimento
# ---------------------
# Reproduz o efeito sonoro na posição da personagem que encheu a cápsula.
func _tocar_som(posicao: Vector2) -> void:

	if som_encher == null:

		return

	var audio: AudioStreamPlayer2D = $SomEncher
	audio.global_position = posicao
	audio.stream = som_encher
	audio.bus = barramento_som if AudioServer.get_bus_index(barramento_som) >= 0 else &"Master"
	audio.volume_db = volume_encher_db
	audio.play()
