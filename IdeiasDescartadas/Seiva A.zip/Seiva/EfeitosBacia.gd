@tool
extends Node2D

@export var reservatorio: NodePath
@export var plataforma: NodePath
@export var chegada_queda: NodePath
@export var ativo: bool = true
@export var cor: Color = Color("b4e8ed")
@export_range(0.0, 2.0) var intensidade: float = 0.65
@export_range(1.0, 100.0) var altura_minima: float = 8.0
@export_range(50.0, 1200.0) var altura_maxima: float = 450.0
@export_range(2, 48) var gotas_maximas: int = 24
@export_range(0.1, 2.0) var duracao_ondas: float = 0.95
@export_range(0.03, 2.0) var intervalo_queda: float = 0.18
@export_range(0.0, 2.0) var intensidade_queda: float = 0.35
@export_range(0.05, 1.0) var intervalo_passos: float = 0.22

var _gotas: Array[Dictionary] = []
var _ondas: Array[Dictionary] = []
var _jogador: CharacterBody2D
var _antes: Vector2
var _topo: float
var _na_agua: bool = false
var _iniciou: bool = false
var _passo: float = 0.0
var _queda: float = 0.0

# Localizar a superfície
# ---------------------
# Converte a largura e o desnível da bacia para este efeito.
func _superficie(x: float) -> Vector2:

	var b: Node2D = get_node_or_null(reservatorio) as Node2D
	if b == null:

		return Vector2.ZERO
	var tamanho: Vector2 = b.get("tamanho")
	var local_x: float = clampf(x, 0.0, tamanho.x)
	return to_local(b.to_global(Vector2(local_x, float(b.get("desnivel")) * local_x / maxf(tamanho.x, 1.0))))

# Encontrar os pés
# ---------------------
# Usa a forma física da personagem sem depender da origem do desenho.
func _pes() -> Vector2:

	var ponto: Vector2 = _jogador.global_position
	for filho in _jogador.get_children():

		if filho is CollisionShape2D and not filho.disabled and filho.shape != null:

			var limites: Rect2 = filho.shape.get_rect()
			var inferior: float = -INF
			for canto in [limites.position, Vector2(limites.end.x, limites.position.y), limites.end, Vector2(limites.position.x, limites.end.y)]:

				inferior = maxf(inferior, filho.to_global(canto).y)
			ponto.y = inferior
			break
	return ponto

# Emitir um impacto
# ---------------------
# Faz a quantidade e a altura das gotas crescerem com a altura da queda.
func respingar(posicao: Vector2, forca: float) -> void:

	var f: float = clampf(forca, 0.0, 1.0) * intensidade
	if f <= 0.0:

		return
	_ondas.append({"p": posicao, "t": 0.0, "f": f})
	var quantidade: int = maxi(2, int(ceilf(gotas_maximas * minf(f, 1.0))))
	for i in range(quantidade):

		if _gotas.size() >= 180:

			break
		_gotas.append({"p": posicao + Vector2(randf_range(-6, 6), 0), "v": Vector2(randf_range(-600, 300), -randf_range(70, 230)) * sqrt(f), "t": 0.0, "vida": randf_range(0.35, 0.7), "r": randf_range(1.3, 3.0) * (0.6 + f)})

# Ler a personagem
# ---------------------
# Detecta pousos, saltos e passos sobre esta bacia.
func _physics_process(delta: float) -> void:

	if Engine.is_editor_hint() or not ativo:

		return
	if not is_instance_valid(_jogador):

		_jogador = get_tree().get_first_node_in_group("jogador") as CharacterBody2D
		_iniciou = false
		if _jogador == null:

			return
	var b: Node2D = get_node_or_null(reservatorio) as Node2D
	if b == null:

		return
	var pes: Vector2 = _pes()
	if not _iniciou:

		_antes = pes
		_topo = pes.y
		_iniciou = true
	_topo = minf(_topo, pes.y)
	var local_pes: Vector2 = b.to_local(pes)
	var tamanho: Vector2 = b.get("tamanho")
	var superficie: Vector2 = _superficie(local_pes.x)
	var altura: float = b.to_local(to_global(superficie)).y
	var dentro: bool = local_pes.x >= 0 and local_pes.x <= tamanho.x
	var apoiada: bool = false
	var corpo: Node = get_node_or_null(plataforma)
	for i in range(_jogador.get_slide_collision_count()):

		if _jogador.get_slide_collision(i).get_collider() == corpo and _jogador.is_on_floor():

			apoiada = true
	var perto: bool = dentro and absf(local_pes.y - altura) < 58.0
	var agora: bool = perto and apoiada
	var cruzou: bool = dentro and b.to_local(_antes).y < altura and local_pes.y >= altura and pes.y > _antes.y
	if (agora and not _na_agua) or (cruzou and not _na_agua):

		var distancia: float = maxf(0.0, pes.y - _topo)
		if distancia >= altura_minima:

			respingar(superficie, clampf(sqrt(distancia / maxf(altura_maxima, 1.0)), 0.12, 1.0))
	if _na_agua and not agora and _jogador.velocity.y < -30:

		respingar(superficie, clampf(absf(_jogador.velocity.y) / 950.0, 0.12, 0.5))
	_passo -= delta
	if agora and absf(_jogador.velocity.x) > 8 and _passo <= 0:

		_ondas.append({"p": superficie, "t": 0.0, "f": 0.23 * intensidade})
		_passo = intervalo_passos
	if _jogador.is_on_floor():

		_topo = pes.y
	_na_agua = agora
	_antes = pes

# Avançar os efeitos
# ---------------------
# Atualiza gotas e ondas e mantém os respingos contínuos da chegada.
func _process(delta: float) -> void:

	if Engine.is_editor_hint() or not ativo:

		return
	_queda -= delta
	var chegada: Node2D = get_node_or_null(chegada_queda) as Node2D if not chegada_queda.is_empty() else null
	var b: Node2D = get_node_or_null(reservatorio) as Node2D
	if chegada != null and b != null and _queda <= 0:

		var x: float = b.to_local(chegada.global_position).x
		respingar(_superficie(x), intensidade_queda * randf_range(0.65, 1.0))
		_queda = maxf(intervalo_queda, 0.03)
	for i in range(_gotas.size() - 1, -1, -1):

		var g: Dictionary = _gotas[i]
		g["t"] += delta
		g["v"] += Vector2(0, 420) * delta
		g["p"] += g["v"] * delta
		if g["t"] >= g["vida"] or (g["v"].y > 0 and b != null and b.to_local(to_global(g["p"])).y > 20):

			_gotas.remove_at(i)
	for i in range(_ondas.size() - 1, -1, -1):

		_ondas[i]["t"] += delta
		if _ondas[i]["t"] >= duracao_ondas:

			_ondas.remove_at(i)
	queue_redraw()

# Desenhar água em movimento
# ---------------------
# Usa gotas arredondadas e anéis suaves limitados à superfície da bacia.
func _draw() -> void:

	var b: Node2D = get_node_or_null(reservatorio) as Node2D
	if b == null:

		return
	var tamanho: Vector2 = b.get("tamanho")
	for onda in _ondas:

		var t: float = float(onda["t"]) / maxf(duracao_ondas, 0.01)
		var raio: float = lerpf(3, 55, t) * (0.7 + float(onda["f"]))
		var linha := PackedVector2Array()
		for k in range(49):

			var a: float = TAU * float(k) / 48.0
			var ponto: Vector2 = onda["p"] + Vector2(cos(a) * raio, sin(a) * raio * 0.16)
			var local_p: Vector2 = b.to_local(to_global(ponto))
			local_p.x = clampf(local_p.x, 1.0, tamanho.x - 1.0)
			linha.append(to_local(b.to_global(local_p)))
		var c: Color = cor
		c.a *= (1.0 - smoothstep(0.0, 1.0, t)) * 0.65
		draw_polyline(linha, c, 1.25, true)
	for g in _gotas:

		var t: float = float(g["t"]) / float(g["vida"])
		var c: Color = cor
		c.a *= smoothstep(0.0, 0.08, t) * (1.0 - smoothstep(0.45, 1.0, t))
		var v: Vector2 = g["v"]
		var r: float = g["r"]
		var eixo: Vector2 = v.normalized() * r * minf(v.length() / 100.0, 1.6)
		draw_line(g["p"] - eixo * 0.5, g["p"] + eixo * 0.5, c, r * 2, true)
		draw_circle(g["p"] - eixo * 0.5, r, c, true, -1, true)
		draw_circle(g["p"] + eixo * 0.5, r, c, true, -1, true)
